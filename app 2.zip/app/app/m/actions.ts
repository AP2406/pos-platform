"use server";

import { createClient } from "@/lib/supabase/server";
import { requireBusiness, listBusinesses } from "@/lib/services/tenancy";
import { getTodayBoundsUTC } from "@/lib/utils/dates";
import { notifyBusiness } from "@/lib/push";

export type LocationLive = {
  id: string;
  name: string;
  net: number;
  orders: number;
  openChecks: number;
  openValue: number;
};

export type RecentSale = { id: string; location: string; label: string; total: number; at: string };

export type Alerts = {
  voids: { n: number; amt: number };
  unassigned: number;
  openDrawers: number;
  staleChecks: number;
  oldestCheckMin: number;
  // D4: today's labor % is over the active business's target (null when under or off).
  laborOverTarget: { pct: number; target: number } | null;
};

export type Snapshot = {
  currency: string;
  locations: LocationLive[];
  totals: { net: number; orders: number; openChecks: number; openValue: number };
  avgTicket: number;
  recent: RecentSale[];
  alerts: Alerts;
  // A9 on-pace: covers + labor % today, and the same-day-last-week net for pacing.
  covers: number;
  salesPerCover: number;
  laborCost: number;
  laborPct: number | null;
  lastWeekNet: number;
};

function num(v: unknown): number {
  return Number(v) || 0;
}

function cartValue(cart: unknown): number {
  const items = (cart as { items?: { unit_price?: unknown; quantity?: unknown }[] } | null)?.items;
  if (!Array.isArray(items)) return 0;
  let sum = 0;
  for (const it of items) sum += num(it.unit_price) * num(it.quantity);
  return Math.round(sum * 100) / 100;
}

export async function liveSnapshot(): Promise<Snapshot> {
  const { business } = await requireBusiness();
  const tz = business.timezone || "America/Toronto";
  const currency = (business.currency || "USD").toUpperCase();
  const bounds = getTodayBoundsUTC(tz);
  const startIso = bounds.start.toISOString();
  const lwStartIso = new Date(bounds.start.getTime() - 7 * 86400000).toISOString();
  const lwEndIso = new Date(bounds.end.getTime() - 7 * 86400000).toISOString();
  const supabase = await createClient();

  const mine = (await listBusinesses()).filter(
    (b) => b.role === "owner" || b.role === "manager"
  );
  const ids = mine.map((b) => b.id);
  const nameById = new Map(mine.map((b) => [b.id, b.name]));

  const [
    { data: orders },
    { data: refunds },
    { data: tickets },
    { data: recentRows },
    { data: voidEvents },
    { data: openDrawerRows },
    { data: staffCounts },
  ] = await Promise.all([
    supabase
      .from("orders")
      .select("business_id, total, status, staff_id, guest_count")
      .in("business_id", ids)
      .gte("created_at", startIso)
      .neq("status", "voided"),
    supabase
      .from("refunds")
      .select("business_id, amount, status")
      .in("business_id", ids)
      .gte("created_at", startIso),
    supabase.from("open_tickets").select("business_id, cart, opened_at").in("business_id", ids),
    supabase
      .from("orders")
      .select("id, business_id, total, sale_number, created_at, status")
      .in("business_id", ids)
      .neq("status", "voided")
      .order("created_at", { ascending: false })
      .limit(8),
    supabase
      .from("audit_events")
      .select("metadata")
      .in("business_id", ids)
      .eq("action", "void")
      .gte("created_at", startIso),
    supabase.from("drawer_sessions").select("business_id").in("business_id", ids).eq("status", "open"),
    supabase.from("staff_members").select("business_id").in("business_id", ids).eq("is_active", true),
  ]);

  // A9: same-day-last-week net + today's labor cost (clocked hours × pay rate).
  const [{ data: lwOrders }, { data: lwRefunds }, { data: clocks }, { data: rates }] = await Promise.all([
    supabase.from("orders").select("total, status").in("business_id", ids).gte("created_at", lwStartIso).lt("created_at", lwEndIso).neq("status", "voided"),
    supabase.from("refunds").select("amount, status").in("business_id", ids).gte("created_at", lwStartIso).lt("created_at", lwEndIso),
    supabase.from("time_clock_entries").select("staff_id, business_id, clock_in, clock_out").in("business_id", ids).or(`clock_out.is.null,clock_in.gte.${startIso}`),
    supabase.from("staff_members").select("id, pay_rate").in("business_id", ids),
  ]);
  let lastWeekNet = 0;
  for (const o of lwOrders ?? []) lastWeekNet += num(o.total);
  for (const r of lwRefunds ?? []) { if ((r.status as string) !== "voided") lastWeekNet -= num(r.amount); }
  lastWeekNet = Math.round(lastWeekNet * 100) / 100;

  const rateById = new Map((rates ?? []).map((s) => [s.id as string, s.pay_rate != null ? Number(s.pay_rate) : null]));
  const todayStartMs = bounds.start.getTime();
  const nowMsL = Date.now();
  let laborCost = 0;
  let activeLaborCost = 0; // D4: just the active business, for the per-business target
  for (const c of clocks ?? []) {
    const inMs = new Date(c.clock_in as string).getTime();
    const outMs = c.clock_out ? new Date(c.clock_out as string).getTime() : nowMsL;
    const overlap = Math.min(outMs, nowMsL) - Math.max(inMs, todayStartMs);
    if (overlap <= 0) continue;
    const rate = rateById.get(c.staff_id as string);
    if (rate != null) {
      const cost = (overlap / 3600000) * rate;
      laborCost += cost;
      if ((c.business_id as string) === business.id) activeLaborCost += cost;
    }
  }
  laborCost = Math.round(laborCost * 100) / 100;
  activeLaborCost = Math.round(activeLaborCost * 100) / 100;

  const agg: Record<string, LocationLive> = {};
  for (const b of mine) agg[b.id] = { id: b.id, name: b.name, net: 0, orders: 0, openChecks: 0, openValue: 0 };

  for (const o of orders ?? []) {
    const a = agg[o.business_id as string];
    if (!a) continue;
    a.net += num(o.total);
    a.orders += 1;
  }
  for (const r of refunds ?? []) {
    if ((r.status as string) === "voided") continue;
    const a = agg[r.business_id as string];
    if (a) a.net -= num(r.amount);
  }
  for (const t of tickets ?? []) {
    const a = agg[t.business_id as string];
    if (!a) continue;
    a.openChecks += 1;
    a.openValue += cartValue(t.cart);
  }

  const locations = Object.values(agg)
    .map((l) => ({ ...l, net: Math.round(l.net * 100) / 100, openValue: Math.round(l.openValue * 100) / 100 }))
    .sort((a, b) => b.net - a.net);

  const totals = locations.reduce(
    (t, l) => ({
      net: Math.round((t.net + l.net) * 100) / 100,
      orders: t.orders + l.orders,
      openChecks: t.openChecks + l.openChecks,
      openValue: Math.round((t.openValue + l.openValue) * 100) / 100,
    }),
    { net: 0, orders: 0, openChecks: 0, openValue: 0 }
  );

  const recent: RecentSale[] = (recentRows ?? []).map((o) => ({
    id: o.id as string,
    location: nameById.get(o.business_id as string) ?? "",
    label: o.sale_number ? "#" + o.sale_number : "Sale",
    total: num(o.total),
    at: o.created_at as string,
  }));

  // Manager alert signals.
  const staffedBiz = new Set((staffCounts ?? []).map((s) => s.business_id as string));
  let unassigned = 0;
  for (const o of orders ?? []) {
    if (!o.staff_id && staffedBiz.has(o.business_id as string)) unassigned++;
  }
  let voidN = 0;
  let voidAmt = 0;
  for (const v of voidEvents ?? []) {
    voidN++;
    const m = v.metadata as { amount?: number } | null;
    if (m && typeof m.amount === "number") voidAmt += m.amount;
  }
  const nowMs = Date.now();
  let staleChecks = 0;
  let oldestMin = 0;
  for (const t of tickets ?? []) {
    const opened = t.opened_at as string | null;
    if (!opened) continue;
    const mins = Math.floor((nowMs - new Date(opened).getTime()) / 60000);
    if (mins >= 90) staleChecks++;
    if (mins > oldestMin) oldestMin = mins;
  }
  // D4: labor-target alert for the active business. When today's labor % is over
  // the configured target, surface it + push to managers once per day (mirrors
  // the void-over-$ alert). Best-effort; never blocks the snapshot.
  let laborOverTarget: { pct: number; target: number } | null = null;
  const ltCfg = (((business as { settings?: Record<string, unknown> }).settings ?? {}) as Record<string, unknown>).labor_target as
    | { enabled?: boolean; targetPct?: number; alerted_on?: string }
    | undefined;
  if (ltCfg?.enabled === true && Number(ltCfg.targetPct) > 0) {
    const activeNet = agg[business.id]?.net ?? 0;
    if (activeNet > 0) {
      const activePct = Math.round((activeLaborCost / activeNet) * 1000) / 10;
      const target = Number(ltCfg.targetPct);
      if (activePct > target) {
        laborOverTarget = { pct: activePct, target };
        const todayKey = new Intl.DateTimeFormat("en-CA", { timeZone: tz }).format(new Date());
        if (ltCfg.alerted_on !== todayKey) {
          try {
            const settings = ((business as { settings?: Record<string, unknown> }).settings ?? {}) as Record<string, unknown>;
            await supabase
              .from("businesses")
              .update({ settings: { ...settings, labor_target: { ...ltCfg, alerted_on: todayKey } } })
              .eq("id", business.id);
            await notifyBusiness(business.id, "exception", {
              title: "Labor over target",
              body: `Labor is ${activePct}% of sales today (target ${target}%).`,
              url: "/app/labor",
            });
          } catch (e) {
            console.error("labor target alert:", e);
          }
        }
      }
    }
  }

  const alerts: Alerts = {
    voids: { n: voidN, amt: Math.round(voidAmt * 100) / 100 },
    unassigned,
    openDrawers: (openDrawerRows ?? []).length,
    staleChecks,
    oldestCheckMin: oldestMin,
    laborOverTarget,
  };

  let covers = 0;
  for (const o of orders ?? []) covers += num(o.guest_count);

  return {
    currency,
    locations,
    totals,
    avgTicket: totals.orders > 0 ? Math.round((totals.net / totals.orders) * 100) / 100 : 0,
    recent,
    alerts,
    covers,
    salesPerCover: covers > 0 ? Math.round((totals.net / covers) * 100) / 100 : 0,
    laborCost,
    laborPct: totals.net > 0 ? Math.round((laborCost / totals.net) * 1000) / 10 : null,
    lastWeekNet,
  };
}
