"use client";

import { useState, useTransition } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { addShift, deleteShift, publishWeek, saveWeekAsTemplate, applyTemplate, deleteShiftTemplate, moveShift, addTimeOff, deleteTimeOff, requestShiftSwap, type ShiftTemplate } from "./actions";

type Staff = { id: string; name: string; active: boolean };
type TimeOffRow = { id: string; staffId: string; staffName: string; date: string; note: string | null };
type Shift = {
  id: string; staffId: string; staffName: string; dayKey: string;
  timeLabel: string; roleLabel: string | null; note: string | null; published: boolean; hours: number;
};
type DayLabel = { key: string; label: string };
type Variance = { id: string; name: string; scheduled: number; actual: number };

type Forecast = { cost: number; hours: number; sales: number; laborPct: number | null; coverage: number };

export function ScheduleClient({
  staff, shifts, days, variance, monday, prevWeek, nextWeek, startIso, endIso, anyUnpublished, forecast, templates, timeOff,
}: {
  staff: Staff[]; shifts: Shift[]; days: DayLabel[]; variance: Variance[];
  monday: string; prevWeek: string; nextWeek: string; startIso: string; endIso: string; anyUnpublished: boolean; forecast: Forecast; templates: ShiftTemplate[]; timeOff: TimeOffRow[];
}) {
  const router = useRouter();
  const [pending, start] = useTransition();
  const [err, setErr] = useState<string | null>(null);
  const [tplName, setTplName] = useState("");
  const [tplPick, setTplPick] = useState(templates[0]?.id ?? "");
  const [dragId, setDragId] = useState<string | null>(null);
  const [overDay, setOverDay] = useState<string | null>(null);

  function drop(dayKey: string) {
    const id = dragId;
    setDragId(null);
    setOverDay(null);
    if (!id) return;
    setErr(null);
    start(async () => {
      const res = await moveShift(id, dayKey);
      if ("error" in res) { setErr(res.error); return; }
      refresh();
    });
  }

  const assignable = staff.filter((s) => s.active);
  const [staffId, setStaffId] = useState(assignable[0]?.id ?? "");
  const [date, setDate] = useState(days[0]?.key ?? monday);
  const [from, setFrom] = useState("09:00");
  const [to, setTo] = useState("17:00");
  const [roleLabel, setRoleLabel] = useState("");

  function refresh() {
    router.refresh();
  }

  const offByStaffDate = new Set(timeOff.map((t) => t.staffId + "|" + t.date));
  function add() {
    setErr(null);
    if (offByStaffDate.has(staffId + "|" + date)) {
      setErr("That staff member has time off that day — remove it first or pick another.");
      return;
    }
    start(async () => {
      const res = await addShift({ staffId, date, start: from, end: to, roleLabel: roleLabel || undefined });
      if ("error" in res) { setErr(res.error); return; }
      setRoleLabel("");
      refresh();
    });
  }
  function remove(id: string) {
    setErr(null);
    start(async () => {
      const res = await deleteShift(id);
      if ("error" in res) { setErr(res.error); return; }
      refresh();
    });
  }
  function publish() {
    setErr(null);
    start(async () => {
      const res = await publishWeek(startIso, endIso);
      if ("error" in res) { setErr(res.error); return; }
      refresh();
    });
  }
  function saveTpl() {
    setErr(null);
    start(async () => {
      const res = await saveWeekAsTemplate(tplName, startIso, endIso);
      if ("error" in res) { setErr(res.error); return; }
      setTplName("");
      refresh();
    });
  }
  function applyTpl() {
    if (!tplPick) return;
    setErr(null);
    start(async () => {
      const res = await applyTemplate(tplPick, monday);
      if ("error" in res) { setErr(res.error); return; }
      refresh();
    });
  }
  function removeTpl(id: string) {
    setErr(null);
    start(async () => {
      const res = await deleteShiftTemplate(id);
      if ("error" in res) { setErr(res.error); return; }
      refresh();
    });
  }

  const [offStaff, setOffStaff] = useState(assignable[0]?.id ?? "");
  const [offDate, setOffDate] = useState(days[0]?.key ?? monday);
  const [swapShift, setSwapShift] = useState("");
  const [swapTo, setSwapTo] = useState("");
  const [swapMsg, setSwapMsg] = useState<string | null>(null);

  function addOff() {
    setErr(null);
    start(async () => {
      const res = await addTimeOff(offStaff, offDate);
      if ("error" in res) { setErr(res.error); return; }
      refresh();
    });
  }
  function removeOff(id: string) {
    setErr(null);
    start(async () => {
      const res = await deleteTimeOff(id);
      if ("error" in res) { setErr(res.error); return; }
      refresh();
    });
  }
  function sendSwap() {
    if (!swapShift || !swapTo) return;
    setErr(null); setSwapMsg(null);
    start(async () => {
      const res = await requestShiftSwap(swapShift, swapTo);
      if ("error" in res) { setErr(res.error); return; }
      setSwapShift(""); setSwapTo("");
      setSwapMsg("Sent to Approvals.");
    });
  }

  return (
    <div>
      <div className="mb-5 flex items-start justify-between gap-3">
        <div>
          <h1 className="text-2xl font-semibold">Schedule</h1>
          <p className="text-muted-foreground text-sm mt-1">Week of {monday}. Add shifts, publish, and compare to actual hours.</p>
        </div>
        <div className="flex items-center gap-2 shrink-0">
          <Link href={"/app/schedule?week=" + prevWeek} className="text-sm rounded-md border border-border px-2.5 py-1.5 hover:bg-accent">←</Link>
          <Link href="/app/schedule" className="text-sm rounded-md border border-border px-2.5 py-1.5 hover:bg-accent">This week</Link>
          <Link href={"/app/schedule?week=" + nextWeek} className="text-sm rounded-md border border-border px-2.5 py-1.5 hover:bg-accent">→</Link>
          {anyUnpublished && (
            <Button size="sm" onClick={publish} disabled={pending}>Publish week</Button>
          )}
        </div>
      </div>

      {err && <p className="text-sm text-red-600 mb-3">{err}</p>}

      <div className="bg-card ring-1 ring-line shadow-elevation rounded-xl p-4 mb-4">
        <div className="flex flex-wrap items-end gap-2">
          <div className="space-y-1">
            <Label className="text-xs">Staff</Label>
            <select value={staffId} onChange={(e) => setStaffId(e.target.value)} className="h-9 rounded-md border border-border bg-transparent text-foreground px-2 text-sm">
              {assignable.map((s) => <option key={s.id} value={s.id}>{s.name}</option>)}
            </select>
          </div>
          <div className="space-y-1">
            <Label className="text-xs">Day</Label>
            <select value={date} onChange={(e) => setDate(e.target.value)} className="h-9 rounded-md border border-border bg-transparent text-foreground px-2 text-sm">
              {days.map((d) => <option key={d.key} value={d.key}>{d.label}</option>)}
            </select>
          </div>
          <div className="space-y-1">
            <Label className="text-xs">From</Label>
            <Input type="time" value={from} onChange={(e) => setFrom(e.target.value)} className="h-9 w-28" />
          </div>
          <div className="space-y-1">
            <Label className="text-xs">To</Label>
            <Input type="time" value={to} onChange={(e) => setTo(e.target.value)} className="h-9 w-28" />
          </div>
          <div className="space-y-1">
            <Label className="text-xs">Role (optional)</Label>
            <Input value={roleLabel} onChange={(e) => setRoleLabel(e.target.value)} placeholder="Server" className="h-9 w-28" />
          </div>
          <Button onClick={add} disabled={pending || !staffId}>Add shift</Button>
        </div>
      </div>

      <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-3 mb-4">
        {days.map((d) => {
          const dayShifts = shifts.filter((s) => s.dayKey === d.key);
          return (
            <div
              key={d.key}
              onDragOver={(e) => { if (dragId) { e.preventDefault(); setOverDay(d.key); } }}
              onDragLeave={() => setOverDay((cur) => (cur === d.key ? null : cur))}
              onDrop={(e) => { e.preventDefault(); drop(d.key); }}
              className={"bg-card ring-1 shadow-elevation rounded-xl p-3 transition-colors " + (overDay === d.key ? "ring-foreground bg-accent/40" : "ring-line")}
            >
              <div className="text-xs font-semibold uppercase tracking-wide text-muted-foreground mb-2">{d.label}</div>
              {timeOff.filter((t) => t.date === d.key).map((t) => (
                <div key={t.id} className="text-[11px] text-amber-600 mb-1 flex items-center justify-between gap-1">
                  <span>{t.staffName} — off</span>
                  <button type="button" onClick={() => removeOff(t.id)} className="underline hover:text-red-600">✕</button>
                </div>
              ))}
              {dayShifts.length === 0 ? (
                <div className="text-xs text-muted-foreground">{dragId ? "Drop here" : "—"}</div>
              ) : (
                <div className="space-y-1.5">
                  {dayShifts.map((s) => (
                    <div
                      key={s.id}
                      draggable
                      onDragStart={() => setDragId(s.id)}
                      onDragEnd={() => { setDragId(null); setOverDay(null); }}
                      className={"text-sm rounded-md border border-border px-2 py-1.5 cursor-grab active:cursor-grabbing " + (dragId === s.id ? "opacity-50" : "")}
                    >
                      <div className="flex items-center justify-between gap-1">
                        <span className="font-medium truncate">{s.staffName}</span>
                        <button type="button" onClick={() => remove(s.id)} disabled={pending} className="text-xs text-muted-foreground hover:text-red-600">✕</button>
                      </div>
                      <div className="text-xs text-muted-foreground">
                        {s.timeLabel}{s.roleLabel ? " · " + s.roleLabel : ""}
                        {!s.published && <span className="ml-1 text-amber-600">draft</span>}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          );
        })}
      </div>

      <div className="bg-card ring-1 ring-line shadow-elevation rounded-xl p-4 mb-4">
        <div className="text-xs font-semibold uppercase tracking-wide text-muted-foreground mb-2">Templates</div>
        <div className="flex flex-wrap items-end gap-2">
          <div className="flex items-end gap-1.5">
            <div className="space-y-1">
              <Label className="text-xs">Save this week as</Label>
              <Input value={tplName} onChange={(e) => setTplName(e.target.value)} placeholder="Standard week" className="h-9 w-44" />
            </div>
            <Button variant="outline" className="h-9" onClick={saveTpl} disabled={pending || !tplName.trim()}>Save</Button>
          </div>
          {templates.length > 0 && (
            <div className="flex items-end gap-1.5">
              <div className="space-y-1">
                <Label className="text-xs">Apply a template to this week</Label>
                <select value={tplPick} onChange={(e) => setTplPick(e.target.value)} className="h-9 w-52 rounded-md border border-border bg-transparent px-2 text-sm">
                  {templates.map((t) => <option key={t.id} value={t.id}>{t.name} ({t.count})</option>)}
                </select>
              </div>
              <Button variant="outline" className="h-9" onClick={applyTpl} disabled={pending || !tplPick}>Apply</Button>
              <button type="button" onClick={() => removeTpl(tplPick)} disabled={pending} className="text-xs text-muted-foreground underline hover:text-red-600 pb-2">Delete</button>
            </div>
          )}
        </div>
        <p className="text-[11px] text-muted-foreground mt-2">Applying adds the template&apos;s assigned shifts to this week as unpublished drafts (unassigned slots are skipped).</p>
      </div>

      <div className="bg-card ring-1 ring-line shadow-elevation rounded-xl p-4 mb-4">
        <div className="text-xs font-semibold uppercase tracking-wide text-muted-foreground mb-2">Time off &amp; swaps</div>
        <div className="flex flex-wrap items-end gap-x-4 gap-y-2">
          <div className="flex items-end gap-1.5">
            <div className="space-y-1">
              <Label className="text-xs">Time off</Label>
              <select value={offStaff} onChange={(e) => setOffStaff(e.target.value)} className="h-9 w-36 rounded-md border border-border bg-transparent px-2 text-sm">
                {assignable.map((s) => <option key={s.id} value={s.id}>{s.name}</option>)}
              </select>
            </div>
            <select value={offDate} onChange={(e) => setOffDate(e.target.value)} className="h-9 w-40 rounded-md border border-border bg-transparent px-2 text-sm">
              {days.map((d) => <option key={d.key} value={d.key}>{d.label}</option>)}
            </select>
            <Button variant="outline" className="h-9" onClick={addOff} disabled={pending || !offStaff}>Mark off</Button>
          </div>
          <div className="flex items-end gap-1.5">
            <div className="space-y-1">
              <Label className="text-xs">Swap shift</Label>
              <select value={swapShift} onChange={(e) => setSwapShift(e.target.value)} className="h-9 w-48 rounded-md border border-border bg-transparent px-2 text-sm">
                <option value="">Pick a shift…</option>
                {shifts.map((s) => <option key={s.id} value={s.id}>{s.staffName} · {s.dayKey.slice(5)} {s.timeLabel}</option>)}
              </select>
            </div>
            <select value={swapTo} onChange={(e) => setSwapTo(e.target.value)} className="h-9 w-36 rounded-md border border-border bg-transparent px-2 text-sm">
              <option value="">to…</option>
              {assignable.map((s) => <option key={s.id} value={s.id}>{s.name}</option>)}
            </select>
            <Button variant="outline" className="h-9" onClick={sendSwap} disabled={pending || !swapShift || !swapTo}>Request</Button>
            {swapMsg && <span className="text-xs text-emerald-600 pb-2">{swapMsg}</span>}
          </div>
        </div>
        <p className="text-[11px] text-muted-foreground mt-2">Scheduling a shift on someone&apos;s day off is blocked. Swap requests go to Approvals; on approve the shift is reassigned.</p>
      </div>

      {forecast.hours > 0 && (
        <div className="bg-card ring-1 ring-line shadow-elevation rounded-xl p-4 mb-4">
          <div className="text-xs font-semibold uppercase tracking-wide text-muted-foreground mb-2">Labor forecast (this week)</div>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-sm">
            <div><div className="text-muted-foreground text-xs">Scheduled hours</div><div className="text-lg font-semibold tabular-nums">{forecast.hours.toFixed(1)}</div></div>
            <div><div className="text-muted-foreground text-xs">Projected labor</div><div className="text-lg font-semibold tabular-nums">{"$" + forecast.cost.toFixed(2)}</div></div>
            <div><div className="text-muted-foreground text-xs">Forecast sales</div><div className="text-lg font-semibold tabular-nums">{forecast.sales > 0 ? "$" + forecast.sales.toFixed(0) : "—"}</div></div>
            <div><div className="text-muted-foreground text-xs">Projected labor %</div><div className={"text-lg font-semibold tabular-nums " + (forecast.laborPct != null && forecast.laborPct > 30 ? "text-amber-600" : "")}>{forecast.laborPct != null ? forecast.laborPct + "%" : "—"}</div></div>
          </div>
          <p className="text-[11px] text-muted-foreground mt-2">
            Sales forecast = trailing 4-week average. {forecast.coverage < 100 ? forecast.coverage + "% of scheduled hours have a pay rate set (others count as $0)." : "Set pay rates under Team."}
          </p>
        </div>
      )}

      {variance.length > 0 && (
        <div className="bg-card ring-1 ring-line shadow-elevation rounded-xl overflow-hidden">
          <div className="px-3 py-2 text-xs font-semibold uppercase tracking-wide text-muted-foreground border-b border-border">
            Scheduled vs actual (this week)
          </div>
          <table className="w-full text-sm">
            <tbody>
              {variance.map((v) => {
                const diff = Math.round((v.actual - v.scheduled) * 10) / 10;
                return (
                  <tr key={v.id} className="border-b border-border last:border-0">
                    <td className="px-3 py-2 font-medium">{v.name}</td>
                    <td className="px-3 py-2 text-right tabular-nums text-muted-foreground">{v.scheduled.toFixed(1)}h sched</td>
                    <td className="px-3 py-2 text-right tabular-nums">{v.actual.toFixed(1)}h actual</td>
                    <td className={"px-3 py-2 text-right tabular-nums " + (Math.abs(diff) >= 2 ? "text-amber-600 font-semibold" : "text-muted-foreground")}>
                      {(diff > 0 ? "+" : "") + diff.toFixed(1)}h
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
